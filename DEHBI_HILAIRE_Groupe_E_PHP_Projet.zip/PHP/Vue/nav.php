<link rel="stylesheet" href="CSS/nav.css">
<nav>
    <ul>
        <li><a href="menuPrincipale.php">Accueil</a></li>
        <li><a href="afficher_matches.php">🏀 Liste de match</a></li>
        <li><a href="afficher_joueurs.php">👤 Joueurs</a></li>
        <li><a href="statistique.php">📊 Statistique</a></li>
        <li>
            <form action="deconnexion.php" method="POST" style="display:inline;">
                <input type="submit" name="Deconnexion" value="Deconnexion">
            </form>
        </li>
    </ul>
</nav>
<hr> ```