<link rel="stylesheet" href="CSS/footer.css">
<hr>
<footer>
    <div>
        <p>&copy; <?php echo date('Y'); ?> - 🏀 Gestion Basket Club</p>
        <p>Projet PHP - Gestion des feuilles de match et statistiques</p>
    </div>

    <div>
        <nav>
            <a href="menuPrincipale.php">Accueil</a> | 
            <a href="afficher_matches.php">Liste des Matches</a> | 
            <a href="statistique.php">Statistiques</a>
        </nav>
    </div>
</footer>